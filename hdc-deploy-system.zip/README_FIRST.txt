WHAT'S IN THIS ZIP
-------------------
deploy_hook.py            <- the whole auto-deploy system (one file)
wsgi_dispatch_snippet.py  <- paste this into your PythonAnywhere WSGI file
.gitignore                <- updated to ignore deploy_secret.txt (your key)

HOW TO PUSH THIS FROM GITHUB'S WEBSITE (no git needed)
--------------------------------------------------------
1. Go to https://github.com/rehmaahmed11/HDC-MAIN
2. First DELETE the old files (click each -> trash icon -> commit):
     deploy_receiver.py
     ops/pythonanywhere/README.md
     ops/pythonanywhere/deploy.sh
     ops/pythonanywhere/production.env.example
     ops/pythonanywhere/setup.py
     ops/pythonanywhere/sync.sh
     ops/pythonanywhere/wsgi_config.example.py
     ops/pythonanywhere/wsgi_deploy_with_receiver.example.py
3. Click "Add file" -> "Upload files" (top right of the repo) and drag in:
     deploy_hook.py
     wsgi_dispatch_snippet.py
     .gitignore   (this will overwrite/update the existing one)
4. Commit directly to main.

THEN ON PYTHONANYWHERE
-----------------------
1. Bash console: git clone https://github.com/rehmaahmed11/HDC-MAIN.git
   (or git pull if you already cloned it)
2. In that folder, create a NEW file called deploy_secret.txt
   -> paste ONE line: any random string you make up. This is your "key".
   Never commit this file (it's already gitignored).
3. Open deploy_hook.py, edit the two paths near the top:
     REPO_DIR  = "/home/YOURUSERNAME/HDC-MAIN"
     WSGI_FILE = "/var/www/yourusername_pythonanywhere_com_wsgi.py"
4. Web tab -> click your WSGI file link -> replace its contents with
   wsgi_dispatch_snippet.py's content -> edit the path at the top of
   THAT file too, to match your clone location.
5. Web tab -> Reload (once, by hand).

THEN ON GITHUB (webhook)
--------------------------
Repo -> Settings -> Webhooks -> Add webhook:
   Payload URL : https://<you>.pythonanywhere.com/deploy
   Content type: application/json
   Secret      : the exact same string you put in deploy_secret.txt
   Events      : Just the push event

FROM NOW ON
-----------
Push to main -> auto pulled -> auto reloaded.
Check it worked: open https://<you>.pythonanywhere.com/deploy in a
browser -> shows the last few deploys with timestamp + commit hash.
